## Readme.md

This React application allows you to securely upload medical data to the Interplanetary File System (IPFS) using the Verbwire API.

### Key Features:

- File selection and upload functionality
- Real-time feedback on upload status
- Display of the IPFS URL after successful upload

### Setup:

**Prerequisites:**

- Node.js and npm installed
- Vercel account (for deployment)

**Installation:**

1. Clone this repository: `git clone https://github.com/your-username/verbwire-medical-data-upload`
2. Install dependencies: `npm install`

### Usage:

1. Run the development server: `npm run dev`
2. Open the app in your browser at `http://localhost:3000`
3. Select a medical data file to upload.
4. Click the "Upload File" button.

### Deployment:

Once you are satisfied with the app's functionality, you can deploy it to Vercel using the following steps:

1. Create a new project in Vercel and connect it to your GitHub repository.
2. Deploy the `main` branch to the `Production` environment.
3. Once the deployment is complete, your app will be available at a unique URL provided by Vercel.

### Technology Stack:

- React
- Next.js
- Verbwire API
- IPFS