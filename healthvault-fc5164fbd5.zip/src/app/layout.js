import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'HealthVault: Your Personal Health Data Vault',
  description: 'healthvault is a cloud-based medical data storage app that securely stores and manages your health information. it leverages verbwire api for secure and efficient data transfer.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}